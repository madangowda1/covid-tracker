import React from 'react'
import Covid from "./componenets/covid";

const App = () => {
  return (
    <>
    <Covid/>
    </>
    )
  }

export default App